import os
import sys
import json
import time
import hashlib
import threading
import queue
import re
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

try:
    import psutil
except ImportError:
    psutil = None

APP_NAME = "LENNOX SCAN"
SUSPICIOUS_TERMS = [
    "freefire", "free fire", "ffpanel", "panel", "aimbot", "aim_bot",
    "aim assist", "esp", "wallhack", "injector", "injected", "cheat",
    "mod menu", "modmenu", "memory editor", "game guardian", "dll injector",
    "undetected", "bypass", "crack", "keygen", "patcher", "loader"
]
SUSPICIOUS_EXTENSIONS = {".asi", ".dll", ".sys", ".exe", ".scr", ".bat", ".cmd", ".ps1", ".lua", ".ahk", ".inject"}
TEXT_EXTENSIONS = {".txt", ".ini", ".cfg", ".json", ".xml", ".log", ".lua", ".ps1", ".bat", ".cmd", ".ahk", ".md"}
MAX_TEXT_BYTES = 2 * 1024 * 1024
SKIP_DIRS = {"$recycle.bin", "system volume information", "windows\\winsxs"}

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def inspect_file(path):
    findings = []
    name = path.name.lower()
    # Names are weak indicators and should never be treated as proof.
    matched = [term for term in SUSPICIOUS_TERMS if term in name]
    if matched:
        findings.append({"type": "Suspicious filename", "detail": "Filename contains: " + ", ".join(matched), "severity": "Review"})
    if path.suffix.lower() in {".asi", ".inject"}:
        findings.append({"type": "Potential game-mod artifact", "detail": f"File extension {path.suffix} can be associated with mods/injection, but may be legitimate.", "severity": "Review"})
    if path.suffix.lower() in TEXT_EXTENSIONS:
        try:
            if path.stat().st_size <= MAX_TEXT_BYTES:
                data = path.read_bytes().decode("utf-8", errors="ignore").lower()
                matches = sorted({term for term in SUSPICIOUS_TERMS if term in data})
                if matches:
                    findings.append({"type": "Suspicious text indicator", "detail": "Content contains: " + ", ".join(matches), "severity": "Review"})
        except (OSError, PermissionError):
            pass
    try:
        digest = sha256_file(path)
    except (OSError, PermissionError):
        digest = None
    return {"path": str(path), "size": safe_size(path), "sha256": digest, "findings": findings}

def safe_size(path):
    try:
        return path.stat().st_size
    except OSError:
        return None

def inspect_processes():
    rows = []
    if psutil is None:
        return [{"process": "Process inspection unavailable", "pid": None, "path": "", "findings": ["Install psutil to enable process inspection"]}]
    for proc in psutil.process_iter(["pid", "name", "exe", "cmdline"]):
        try:
            info = proc.info
            name = (info.get("name") or "")
            exe = (info.get("exe") or "")
            cmdline = " ".join(info.get("cmdline") or [])
            haystack = (name + " " + exe + " " + cmdline).lower()
            matches = [term for term in SUSPICIOUS_TERMS if term in haystack]
            if matches:
                rows.append({"process": name, "pid": info.get("pid"), "path": exe, "findings": ["Process metadata contains: " + ", ".join(matches)]})
            # Best-effort loaded-module inspection. Permission/OS restrictions are expected.
            try:
                for m in proc.memory_maps(grouped=False):
                    mpath = getattr(m, "path", "") or ""
                    if mpath and any(term in mpath.lower() for term in SUSPICIOUS_TERMS):
                        rows.append({"process": name, "pid": info.get("pid"), "path": mpath, "findings": ["Loaded module path contains a suspicious indicator"]})
            except (psutil.AccessDenied, psutil.NoSuchProcess, OSError):
                pass
        except (psutil.AccessDenied, psutil.NoSuchProcess, psutil.ZombieProcess, OSError):
            continue
    return rows

class LennoxApp:
    BG = "#08090d"
    PANEL = "#101219"
    PANEL2 = "#151821"
    PINK = "#ff0a91"
    TEXT = "#f4f5f8"
    MUTED = "#9aa2b4"
    GREEN = "#38e6a4"
    AMBER = "#ffcc66"

    def __init__(self, root):
        self.root = root
        self.root.title("LENNOX SCAN")
        self.root.geometry("1240x790")
        self.root.minsize(980, 650)
        self.root.configure(bg=self.BG)
        self.events = queue.Queue()
        self.running = False
        self.stop_flag = threading.Event()
        self.results = []
        self.process_results = []
        self.scan_root = None
        self._style()
        self._build()
        self.root.after(100, self._poll_events)

    def _style(self):
        style = ttk.Style()
        try: style.theme_use("clam")
        except tk.TclError: pass
        style.configure("Treeview", background=self.PANEL, foreground=self.TEXT, fieldbackground=self.PANEL, rowheight=27, borderwidth=0)
        style.configure("Treeview.Heading", background=self.PANEL2, foreground=self.TEXT, relief="flat")
        style.map("Treeview", background=[("selected", "#50213d")], foreground=[("selected", self.TEXT)])
        style.configure("TProgressbar", troughcolor=self.PANEL2, background=self.PINK, bordercolor=self.PANEL2, lightcolor=self.PINK, darkcolor=self.PINK)

    def _build(self):
        sidebar = tk.Frame(self.root, bg="#0c0d12", width=220)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)
        tk.Label(sidebar, text="◉", font=("Segoe UI", 48, "bold"), fg=self.PINK, bg=sidebar["bg"]).pack(pady=(25, 0))
        tk.Label(sidebar, text="LENNOX SCAN", font=("Segoe UI", 19, "bold"), fg=self.TEXT, bg=sidebar["bg"]).pack()
        tk.Label(sidebar, text="GAME SECURITY • ANALYSIS", font=("Segoe UI", 8), fg=self.MUTED, bg=sidebar["bg"]).pack(pady=(5, 28))
        for label, cmd in [("Overview", self.show_overview), ("Deep Scan", self.choose_folder), ("Live Processes", self.scan_processes), ("Scan History", self.show_history), ("Export Report", self.export_report)]:
            b = tk.Button(sidebar, text="  " + label, command=cmd, anchor="w", relief="flat", bd=0, bg=sidebar["bg"], fg=self.TEXT, activebackground="#321329", activeforeground=self.PINK, font=("Segoe UI", 11), padx=17, pady=12, cursor="hand2")
            b.pack(fill="x", padx=9, pady=2)
        tk.Frame(sidebar, bg="#2b2e39", height=1).pack(fill="x", padx=14, pady=(25, 12))
        tk.Label(sidebar, text="Prototype v0.1.0\nIndicators are not proof.", justify="left", font=("Segoe UI", 9), fg=self.MUTED, bg=sidebar["bg"]).pack(side="bottom", anchor="w", padx=16, pady=18)

        main = tk.Frame(self.root, bg=self.BG)
        main.pack(side="left", fill="both", expand=True, padx=22, pady=18)
        top = tk.Frame(main, bg=self.BG); top.pack(fill="x")
        tk.Label(top, text="DETECT   /   ANALYSE   /   PROTECT", font=("Segoe UI", 9), fg=self.MUTED, bg=self.BG).pack(side="left")
        tk.Label(top, text="● LOCAL SCAN • NO UPLOADS", font=("Segoe UI", 9, "bold"), fg=self.GREEN, bg=self.BG).pack(side="right")
        tk.Label(main, text="System Overview", font=("Segoe UI", 26, "bold"), fg=self.TEXT, bg=self.BG).pack(anchor="w", pady=(23, 2))
        tk.Label(main, text="Look for suspicious game panels, cheat artifacts and possible injection indicators.", font=("Segoe UI", 10), fg=self.MUTED, bg=self.BG).pack(anchor="w", pady=(0, 16))

        status = tk.Frame(main, bg=self.PANEL, highlightbackground="#552141", highlightthickness=1)
        status.pack(fill="x", pady=(0, 14))
        left = tk.Frame(status, bg=self.PANEL); left.pack(side="left", fill="both", expand=True, padx=18, pady=15)
        tk.Label(left, text="◇  SCANNER STATUS", font=("Segoe UI", 10, "bold"), fg=self.PINK, bg=self.PANEL).pack(anchor="w")
        self.status_label = tk.Label(left, text="Ready to scan", font=("Segoe UI", 19, "bold"), fg=self.TEXT, bg=self.PANEL)
        self.status_label.pack(anchor="w", pady=(5, 2))
        self.detail_label = tk.Label(left, text="Choose a folder for a recursive scan. Some system files may be inaccessible.", font=("Segoe UI", 9), fg=self.MUTED, bg=self.PANEL)
        self.detail_label.pack(anchor="w")
        right = tk.Frame(status, bg=self.PANEL); right.pack(side="right", padx=18, pady=16)
        self.start_btn = tk.Button(right, text="START DEEP SCAN  ›", command=self.choose_folder, bg=self.PINK, fg="white", activebackground="#d60078", activeforeground="white", relief="flat", bd=0, padx=22, pady=13, font=("Segoe UI", 10, "bold"), cursor="hand2")
        self.start_btn.pack()
        self.stop_btn = tk.Button(right, text="STOP", command=self.stop_scan, bg=self.PANEL2, fg=self.TEXT, relief="flat", bd=0, padx=22, pady=8, state="disabled")
        self.stop_btn.pack(pady=(7,0))
        self.progress = ttk.Progressbar(main, mode="indeterminate")
        self.progress.pack(fill="x", pady=(0, 14))

        stats = tk.Frame(main, bg=self.BG); stats.pack(fill="x", pady=(0, 14))
        self.stat_files = self._stat(stats, "FILES SCANNED", "0")
        self.stat_flags = self._stat(stats, "ITEMS FLAGGED", "0")
        self.stat_proc = self._stat(stats, "PROCESS INDICATORS", "0")
        self.stat_last = self._stat(stats, "LAST SCAN", "Never")

        box = tk.Frame(main, bg=self.PANEL, highlightbackground="#292c37", highlightthickness=1)
        box.pack(fill="both", expand=True)
        head = tk.Frame(box, bg=self.PANEL); head.pack(fill="x", padx=14, pady=12)
        tk.Label(head, text="Scan findings", font=("Segoe UI", 12, "bold"), fg=self.TEXT, bg=self.PANEL).pack(side="left")
        tk.Button(head, text="Export JSON", command=self.export_report, bg=self.PANEL2, fg=self.TEXT, relief="flat", padx=12, pady=5).pack(side="right")
        cols = ("severity", "kind", "path", "detail")
        self.tree = ttk.Treeview(box, columns=cols, show="headings")
        for c, title, width in [("severity","LEVEL",85),("kind","FINDING",170),("path","FILE / PROCESS",330),("detail","DETAIL",430)]:
            self.tree.heading(c, text=title); self.tree.column(c, width=width, minwidth=70, stretch=(c in {"path","detail"}))
        self.tree.pack(fill="both", expand=True, padx=10, pady=(0,10))
        self.footer = tk.Label(main, text="No scan has run yet. Detection is heuristic; use trusted security tools for confirmation.", font=("Segoe UI", 9), fg=self.MUTED, bg=self.BG)
        self.footer.pack(anchor="w", pady=(10,0))

    def _stat(self, parent, title, value):
        frame = tk.Frame(parent, bg=self.PANEL, highlightbackground="#292c37", highlightthickness=1)
        frame.pack(side="left", fill="x", expand=True, padx=(0,8))
        tk.Label(frame, text=title, font=("Segoe UI", 8, "bold"), fg=self.MUTED, bg=self.PANEL).pack(anchor="w", padx=12, pady=(10,3))
        val = tk.Label(frame, text=value, font=("Segoe UI", 16, "bold"), fg=self.TEXT, bg=self.PANEL)
        val.pack(anchor="w", padx=12, pady=(0,10))
        return val

    def show_overview(self):
        self.status_label.config(text="Ready to scan")
        self.detail_label.config(text="Choose a folder for a recursive scan.")
    def choose_folder(self):
        folder = filedialog.askdirectory(title="Choose a folder for LENNOX SCAN")
        if folder:
            self.scan_root = folder
            self.start_scan(folder)
    def start_scan(self, folder):
        if self.running: return
        self.running = True
        self.stop_flag.clear()
        self.results = []
        for item in self.tree.get_children(): self.tree.delete(item)
        self.status_label.config(text="Scanning…")
        self.detail_label.config(text=folder)
        self.start_btn.config(state="disabled")
        self.stop_btn.config(state="normal")
        self.progress.start(12)
        threading.Thread(target=self._scan_worker, args=(folder,), daemon=True).start()

    def _scan_worker(self, folder):
        count = 0
        errors = 0
        for root, dirs, files in os.walk(folder, topdown=True):
            if self.stop_flag.is_set(): break
            dirs[:] = [d for d in dirs if d.lower() not in {"$recycle.bin", "system volume information"}]
            for filename in files:
                if self.stop_flag.is_set(): break
                path = Path(root) / filename
                try:
                    result = inspect_file(path)
                    self.results.append(result)
                    count += 1
                    for f in result["findings"]:
                        self.events.put(("finding", result["path"], f))
                    if count % 100 == 0:
                        self.events.put(("progress", count, len([r for r in self.results if r["findings"]])))
                except Exception:
                    errors += 1
        self.events.put(("done", count, errors, self.stop_flag.is_set()))

    def _poll_events(self):
        try:
            while True:
                event = self.events.get_nowait()
                if event[0] == "finding":
                    _, path, finding = event
                    self.tree.insert("", "end", values=(finding["severity"], finding["type"], path, finding["detail"]))
                elif event[0] == "progress":
                    _, count, flagged = event
                    self.stat_files.config(text=str(count)); self.stat_flags.config(text=str(flagged))
                elif event[0] == "done":
                    _, count, errors, stopped = event
                    self.running = False; self.progress.stop()
                    self.start_btn.config(state="normal"); self.stop_btn.config(state="disabled")
                    flagged = sum(bool(r["findings"]) for r in self.results)
                    self.stat_files.config(text=str(count)); self.stat_flags.config(text=str(flagged))
                    self.stat_last.config(text=datetime.now().strftime("%H:%M"))
                    self.status_label.config(text="Scan stopped" if stopped else "Scan complete")
                    self.detail_label.config(text=f"{count} files checked • {errors} read errors • {flagged} files with indicators")
                    self.footer.config(text="Indicators are heuristic, not proof. Review paths and verify findings with trusted security tools.")
                    self.root.bell()
        except queue.Empty:
            pass
        self.root.after(100, self._poll_events)

    def stop_scan(self):
        self.stop_flag.set()
        self.status_label.config(text="Stopping…")

    def scan_processes(self):
        self.status_label.config(text="Inspecting running processes…")
        self.root.update_idletasks()
        def worker():
            found = inspect_processes()
            self.events.put(("process_done", found))
        threading.Thread(target=worker, daemon=True).start()
        self.root.after(100, self._poll_process_events)

    def _poll_process_events(self):
        try:
            while True:
                ev = self.events.get_nowait()
                if ev[0] == "process_done":
                    found = ev[1]
                    self.process_results = found
                    for item in self.tree.get_children(): self.tree.delete(item)
                    for row in found:
                        for detail in row["findings"]:
                            self.tree.insert("", "end", values=("Review", "Process indicator", row.get("path") or row.get("process"), detail))
                    self.stat_proc.config(text=str(len(found)))
                    self.status_label.config(text="Process inspection complete")
                    self.detail_label.config(text=f"{len(found)} process/module indicators found; absence of indicators does not prove a clean system.")
                    return
        except queue.Empty:
            pass
        self.root.after(150, self._poll_process_events)

    def show_history(self):
        messagebox.showinfo("Scan History", "This prototype keeps current-session results. Export a JSON report to save them.")
    def export_report(self):
        if not self.results and not self.process_results:
            messagebox.showinfo("No results", "Run a file scan or process inspection first.")
            return
        dest = filedialog.asksaveasfilename(title="Save scan report", defaultextension=".json", filetypes=[("JSON report", "*.json")], initialfile="lennox-scan-report.json")
        if not dest: return
        payload = {"app": APP_NAME, "version": "0.1.0-prototype", "generated_at": datetime.now().isoformat(), "scan_root": self.scan_root, "files": self.results, "process_indicators": self.process_results, "notice": "Heuristic indicators are not proof of cheating or malware. No files were deleted or quarantined."}
        with open(dest, "w", encoding="utf-8") as f: json.dump(payload, f, indent=2)
        messagebox.showinfo("Report saved", f"Report saved to:\n{dest}")

def main():
    root = tk.Tk()
    app = LennoxApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
