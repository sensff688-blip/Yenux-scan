# LENNOX SCAN — Windows prototype

This is a starter project for a defensive Windows scanner focused on suspicious game-cheat artifacts and possible process injection indicators.

## What it does
- Recursively scans a chosen folder (or selected common folders) for files.
- Calculates SHA-256 hashes.
- Flags suspicious names/extensions and heuristic strings as **indicators**, not proof.
- Checks running process names and loaded module paths for suspicious indicators (best-effort; access may be limited).
- Exports a JSON report.

## Important limitations
- This prototype is not equivalent to a mature anti-cheat or antivirus product.
- It cannot guarantee detection of every panel, crack, injector, memory-only modification, renamed/packed payload, or deleted artifact.
- A suspicious match is not proof of cheating or malware.
- It does not automatically delete or quarantine files, modify game processes, bypass protections, or upload files anywhere.
- For best results, run only on a PC you own or have permission to scan. Some process/module inspection may require Administrator privileges.

## Run from source
1. Install Python 3.11+ on Windows.
2. Open PowerShell in this folder.
3. Run: `py -m pip install -r requirements.txt`
4. Run: `py lennox_scan.py`
5. Choose a folder and click **Start Deep Scan**.

## Build a Windows executable
On a Windows PC with Python installed:
1. `py -m pip install -r requirements.txt`
2. `py -m PyInstaller --noconfirm --clean --onefile --windowed --name LENNOX_SCAN lennox_scan.py`
3. The executable will be at `dist\LENNOX_SCAN.exe`.

The current environment cannot compile and test a Windows `.exe` directly, so the included build instructions must be run on Windows.
