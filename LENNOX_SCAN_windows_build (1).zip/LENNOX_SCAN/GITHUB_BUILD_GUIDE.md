# Build LENNOX SCAN Windows EXE from a Mac

1. Create/sign in to a GitHub account at https://github.com.
2. Create a **private** repository named `lennox-scan`.
3. Upload the contents of this folder to the repository, including the `.github/workflows/build-windows.yml` file. The easiest route is GitHub's web UI: Add file → Upload files. Ensure `.github/workflows/build-windows.yml` keeps that exact path.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab. If prompted, enable GitHub Actions.
6. Choose **Build LENNOX SCAN for Windows** and click **Run workflow**. You can also push to `main` to trigger a build.
7. Wait for the workflow to finish. Open the successful run and download the `LENNOX_SCAN-Windows` artifact. Unzip it to get `LENNOX_SCAN.exe`.
8. Test it on a Windows computer you own or have permission to use. Windows SmartScreen may warn about an unsigned app; don't bypass warnings unless you trust the build and understand the source.

Notes:
- Keep the repository private if you don't want the source code public.
- This packages the current prototype, not a production-grade anti-cheat.
- Process/module inspection is best-effort and must be validated on Windows. It cannot guarantee detection of every cheat or injection.
